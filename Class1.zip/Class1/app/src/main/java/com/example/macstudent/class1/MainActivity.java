package com.example.macstudent.class1;

import android.content.Intent;
import android.os.Bundle;
import android.support.v7.app.AppCompatActivity;
import android.util.Log;
import android.view.View;
import android.widget.EditText;

public class MainActivity extends AppCompatActivity {


    @Override
    protected void onCreate(Bundle savedInstanceState) {

        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
    }


    public void buttonPressed(View view)
    {
        EditText txtName = (EditText)findViewById(R.id.txtName);
        String n = txtName.getText().toString();

        Log.d("raman", "button pressed");
       // System.out.println("hello");
        Intent i = new Intent(this, Main2Activity.class);
        i.putExtra("username", n);
        i.putExtra("message", "happy birthday");
        startActivity(i);
    }
}
