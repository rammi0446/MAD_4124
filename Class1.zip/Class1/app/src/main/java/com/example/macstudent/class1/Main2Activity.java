package com.example.macstudent.class1;

import android.content.Intent;
import android.os.Bundle;
import android.support.v7.app.AppCompatActivity;
import android.util.Log;
import android.view.View;
import android.widget.EditText;

public class Main2Activity extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main2);

        EditText txt = (EditText) findViewById(R.id.txtName2);

        Intent i = getIntent();
        String  u = i.getStringExtra("username");
        String m = i.getStringExtra("message");
        Log.d("username", u);
        Log.d("message", m);
        txt.setText(u);
    }

    public void buttonGoBackpresses(View view)
    {


        Intent i = new Intent(this, MainActivity.class);
        startActivity(i);
    }
}
