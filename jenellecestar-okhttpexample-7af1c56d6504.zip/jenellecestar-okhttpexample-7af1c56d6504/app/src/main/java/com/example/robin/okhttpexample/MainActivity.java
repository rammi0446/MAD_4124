package com.example.robin.okhttpexample;

import android.os.Bundle;
import android.support.v7.app.AppCompatActivity;
import android.util.Log;
import android.view.View;
import android.widget.Button;
import android.widget.TextView;

import org.json.JSONArray;
import org.json.JSONObject;

import java.io.IOException;

import okhttp3.Call;
import okhttp3.Callback;
import okhttp3.OkHttpClient;
import okhttp3.Request;
import okhttp3.Response;

public class MainActivity extends AppCompatActivity {
    Button button ;
    TextView textview;

    //create http variable
    OkHttpClient client = new OkHttpClient();

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        button = (Button) findViewById(R.id.btn);
        textview = (TextView) findViewById(R.id.label);

    }


   public void getDataPressed(View view)
   {
       //person pressed the button
       textview.setText("helloWorld");


       //website you want to access
       //String URL = "https://dog.ceo/api/breeds/image/random";
       String URL = "https://jsonplaceholder.typicode.com/users";

       //create a request
       Request request = new Request.Builder()
               .url(URL)
               .build();

       client.newCall(request).enqueue(new Callback() {
           @Override
           public void onFailure(Call call, IOException e) {
               //go here if error
               Log.d("Raman", "error !! so sad raman");
           }

           @Override
           public void onResponse(Call call, Response response) throws IOException {
               //go here if successed
               Log.d("Raman", "i got something");
               if(response.isSuccessful())
               {
                   //5. get response
                   final String data = response.body().string();
                   Log.d("response", data);
                   //6. parse response
                   try {
//                       JSONObject obj = new JSONObject(data);
//                       String status = obj.getString("status");
//                      final String imgLink  = obj.getString("message");
//                       Log.d("raman","status is" +status);
//                       Log.d("raman","img  is" +imgLink);


                       JSONObject jsonObj = new JSONObject(data);


                       JSONArray jsonArray = jsonObj.getJSONArray("data");
                       int length = jsonArray.length();
                       for(int i=0;i<length;i++){
                           JSONObject json = jsonArray.getJSONObject(i);
                           String id = json.getString("id");
                           String name=json.getString("name");
                           JSONArray ingArray = json.getJSONArray("name"); // here you are going   to get ingredients
                           for(int j=0;j<ingArray.length();j++){
                               JSONObject ingredObject= ingArray.getJSONObject(j);
                               String ingName = ingredObject.getString("name");//so you are going to get   ingredient name
                               Log.e("name",ingName); // you will get
                           }
                       }
                       //Log.d("raman","name is" +name);


//         MainActivity.this.runOnUiThread(new Runnable() {
//             @Override
//             public void run() {
//                 textview.setText(imgLink);
//             }
//         });
//                   }
//                   catch (Exception e)
//                   {
//                        e.printStackTrace();
//                   }
//                   //7. display
//               }
//
//           }
//       });
                       MainActivity.this.runOnUiThread(new Runnable() {
             @Override
             public void run() {
                // textview.setText(name);
             }
         });
                   }
                   catch (Exception e)
                   {
                        e.printStackTrace();
                   }
                   //7. display
               }

           }
       });

   }
}
